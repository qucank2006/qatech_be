const app = require("./src/app");
const sequelize = require("./src/config/db");

const PORT = process.env.PORT || 5000;

sequelize
  .authenticate()
  .then(() => {
    console.log("Kết nối MySQL thành công");
    app.listen(PORT, () =>
      console.log(`Server đang chạy tại http://localhost:${PORT}`)
    );
  })
  .catch((err) => {
    console.error("Lỗi kết nối DB:", err.message);
  });
